<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	//private $page_id;
	public function index()
	{
		$this->load->library('form_validation');

        $this->load->view('welcome_message');
                               
	}
	public function login()
	{
		if($this->input->post('mysubmit'))
            {     
                 
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('welcome_message');
                }
                else
                {
                	$email = $this->input->post('email');
                	$this->load->model('Login_model');
                	$this->Login_model->login($email); 
                	$this->session->set_userdata(array(
                            'email'=> $email,
                            'logged_in' => TRUE
                    ));
                  if($this->session->userdata('email')) 
                  	{
                  			$data   = array();
					        $data['result'] = $this->Login_model->get_cat();
                  			$this->load->view('home',$data);
     
					}
                    
                	
                }
            }
	}
	public function home()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Login_model');
			 if($this->session->userdata('email')) 
	                  	{
	                  			$data   = array();
						        $data['result'] = $this->Login_model->get_cat();
	                  			$this->load->view('home',$data);
	     
						}
		}
		else
		{
			redirect('welcome','refresh');
		}
	}
	public function get_post()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->library('pagination');
			$this->load->model('Login_model');
			$id = $this->uri->segment(3);
			$this->session->set_userdata(array(
	                            'cat_id'=> $id,
	                            'logged_in' => TRUE
	                    ));
			
			//echo $id;
			//$user['post'] = $this->Login_model->get_posts_model($id);
			$config['base_url'] = 'http://127.0.0.1/prac_test/prac/index.php/welcome/get_post/'.$id."/";
				//$config['total_rows'] = count($this->Login_model->get_posts_model($id));
				$config['total_rows'] = $this->Login_model->record_count($id);
				$config['per_page'] = 2;
				$config['uri_segment'] = 4;
				$config['full_tag_open'] = '<ul class="tsc_pagination tsc_paginationA tsc_paginationA01">';
				$config['full_tag_close'] = '</ul>';
				$config['prev_link'] = '&lt;';
				$config['prev_tag_open'] = '<li>';
				$config['prev_tag_close'] = '</li>';
				$config['next_link'] = '&gt;';
				$config['next_tag_open'] = '<li>';
				$config['next_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="current"><a href="#">';
				$config['cur_tag_close'] = '</a></li>';
				$config['num_tag_open'] = '<li>';
				$config['num_tag_close'] = '</li>';
				 
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';
				 
				$config['first_link'] = '&lt;&lt;';
				$config['last_link'] = '&gt;&gt;';
				$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
	        $user['post'] = $this->Login_model->get_posts_model($id,$config["per_page"], $page);
	        $email_user = $this->session->userdata('email');
	        $user['user_id'] = $this->Login_model->get_userid_model($email_user);
				$this->pagination->initialize($config);
				
			$this->load->view('post',$user);
		}
		else
		{
			redirect('welcome');
		}
	}
	public function add_post()
	{
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{
			$id = $this->uri->segment(3);
			$c_id = $this->session->userdata('cat_id');
			$email_user = $this->session->userdata('email');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('description', 'Description', 'required');


					if ($this->form_validation->run() == FALSE)
	                {
	                        $this->load->view('add_post');
	                	//redirect('welcome/add_post/');
	                }
	                else
	                {
	                	$this->load->model('Login_model');
	                	$u_id = $this->Login_model->get_userid_model($email_user);
	                	$this->Login_model->add_post_model($c_id,$u_id); 
	                	 $this->load->view('add_post');
	                	
	                }
	    }
	    else
	    {
	    	redirect('welcome','refresh');
	    }
	   
	}
	public function single_post()
	{
		//$array_items = array('email', 'cat_id');
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{
			$post_id  = $this->uri->segment(3);
			$this->load->model('Login_model');
			$data['result'] = $this->Login_model->single_post_model($post_id);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('comment', 'Comment', 'required');
			if ($this->form_validation->run() == FALSE) 
			{
				//$this->load->view('single_post');
			} else 
			{
				if ($this->input->post('comment')) 
				{
					$email_user = $this->session->userdata('email');
					$this->load->model('Login_model');
					$u_id = $this->Login_model->get_userid_model($email_user);
					$this->Login_model->add_comment_model($post_id,$u_id);
				}
				
			}
			$email_user = $this->session->userdata('email');
	        $data['user_id'] = $this->Login_model->get_userid_model($email_user);
			$data['comment'] = $this->Login_model->get_comment_model($post_id);
			$this->load->view('single_post',$data);
		}
		else
		{
			redirect('welcome');
		}
	}
	public function edit_post()
	{
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{
			$post_id = $this->uri->segment(3);
			$this->load->model('Login_model');
			$data['result'] = $this->Login_model->single_post_model($post_id);
			$this->load->view('edit_post',$data);
		}
		else
		{
			redirect('welcome','refresh');
		}
	}
	/*public function edit_comment()
	{
		$post_id = $this->uri->segment(3);
		$this->load->model('Login_model');
		$data['result'] = $this->Login_model->single_post_model($post_id);
		$this->load->view('edit_post',$data);
	}*/
	public function update_post()
	{
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{
			$post_id = $this->uri->segment(3);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('description', 'Description', 'required');
			if ($this->form_validation->run() == TRUE) 
			{
				$this->load->model('Login_model');
				if($this->Login_model->update_post_model($post_id))
				{
					$this->edit_post();
					echo "<script>
						alert('Successfully Updated..!!');
						</script>";
					//redirect($_SERVER['HTTP_REFERER']);
				}	
				
			} 
			else 
			{
				$this->edit_post();
			}
		}
		else
		{
			redirect('welcome','refresh');
		}

	}
	public function delete_post()
	{
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{

			$id = $this->uri->segment(3);
		   $this->load->model('Login_model');
		   $this->Login_model->delete_post_model($id);
		   redirect($_SERVER['HTTP_REFERER']);  
		}
		else
		{
			redirect('welcome','refresh');
		}
	}
	public function delete_comment()
	{
		if($this->session->has_userdata('email') && $this->session->has_userdata('cat_id'))
		{

			$id = $this->uri->segment(3);
		   $this->load->model('Login_model');
		   $this->Login_model->delete_comment_model($id);
		   redirect($_SERVER['HTTP_REFERER']);  
		}
		else
		{
			redirect('welcome','refresh');
		}
	}
	public function logout()
	{
		$array_items = array('email', 'cat_id');
		$this->session->unset_userdata($array_items);
		redirect('welcome');
	}
}
