<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	
public function login($email)
{
	$this->db->select('email');
    $this->db->from('login');

    $this->db->where('email', $email );
    $query = $this->db->get();

    if ( $query->num_rows() <= 0 )
    {
        $email = $this->input->post('email');
            $data = array(
                   'email'=>$email                  
                    );
                    $this->db->insert('login',$data);
    }
    
			   
    
  }
  public function add_post_model($c_id,$u_id)
  {
  	 $title = $this->input->post('title');
  	 $description = $this->input->post('description');
            $data = array(
            		'login_id'=>$u_id,
            		'category'=>$c_id,
                   'title'=>$title, 
                   'description'=>$description                 
                    );
                    $this->db->insert('post',$data);	
  }
  public function add_comment_model($post_id,$u_id)
  {
  	$comment = $this->input->post('comment');
  	$data = array(
  			'post_id' => $post_id,
  			'comment' => $comment,
  			'login_id' => $u_id
  		);
  	$this->db->insert('comment', $data);
  }
  public function get_cat()
  {
        $this->db->select('*');
        $this->db->from('category');
        $query = $this->db->get();
        return $result = $query->result();
    
  }
  public function single_post_model($post_id)
  {
  	$this->db->select('*');
  	$this->db->from('post');
  	$this->db->where('post_id', $post_id);
  	$query = $this->db->get();
  	return $result = $query->result();

  }
  public function get_posts_model($id,$limit, $start)
  {
        $this->db->select('*');
        $this->db->from('post');
        $this->db->where('category',$id);
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $result = $query->result();
    
  }
  public function get_comment_model($post_id)
  {
  	$this->db->select('*');
  	$this->db->from('comment');
  	$this->db->where('post_id', $post_id);
  	$query = $this->db->get();
  	return $result = $query->result();

  }
  public function get_userid_model($email)
  {
  	$this->db->select('login_id');
  	$this->db->from('login');
  	$this->db->where('email', $email);
  	//$query = $this->db->get()->row()->login_id;
  	$query = $this->db->get();
	$ret = $query->row();
	return $ret->login_id;
  }
  public function record_count($id) 
  {
  	/*$this->db->where('category',$id);
	return $this->db->count_all("post");*/
	$this->db->where('category', $id);
	$this->db->from('post');
	return $this->db->count_all_results();

  }
  public function update_post_model($post_id)
  {
  	$title =  $this->input->post('title');
  	$description = $this->input->post('description');
  	$data = array(
  		'title'=>$title,
  		'description'=>$description
  		);
  	$this->db->where('post_id', $post_id);
  	$this->db->update('post', $data);
  	return true;
  }
  public function delete_post_model($id)
  {
  	  $this->db->where('post_id', $id);
      $this->db->delete('post'); 
  }
   public function delete_comment_model($id)
  {
  	  $this->db->where('c_id', $id);
      $this->db->delete('comment'); 
  }

}


/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */