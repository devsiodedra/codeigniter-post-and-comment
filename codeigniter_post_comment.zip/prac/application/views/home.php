<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<a href="<?php echo base_url();?>welcome/logout">Logout</a>
<?php $user = $this->session->userdata('email');
//print_r($user);

?>
<h1 align="center">Home</h1>

<?php foreach($result  as $r): ?>
<a href="<?php echo base_url(); ?>welcome/get_post/<?php echo $r->category_id; ?>"><h3 align="center"><?php echo $r->category_name; ?></h3></a>

  
<?php endforeach; ?>

</body>
</html>