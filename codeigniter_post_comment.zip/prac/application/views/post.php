<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>POST</title>
	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}


ul.tsc_pagination { margin:4px 0; padding:0px; height:100%; overflow:hidden; font:12px 'Tahoma'; list-style-type:none; }
ul.tsc_pagination li { float:left; margin:0px; padding:0px; margin-left:5px; }
 
ul.tsc_pagination li a { color:black; display:block; text-decoration:none; padding:7px 10px 7px 10px; }
 
 
ul.tsc_paginationA li a { color:#FFFFFF; border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px; }
 
ul.tsc_paginationA01 li a { color:#474747; border:solid 1px #B6B6B6; padding:6px 9px 6px 9px; background:#E6E6E6; background:-moz-linear-gradient(top, #FFFFFF 1px, #F3F3F3 1px, #E6E6E6); background:-webkit-gradient(linear, 0 0, 0 100%, color-stop(0.02, #FFFFFF), color-stop(0.02, #F3F3F3), color-stop(1, #E6E6E6)); }
ul.tsc_paginationA01 li:hover a,
ul.tsc_paginationA01 li.current a { background:#53802f; }
	</style>
</head>
<body>
<a href="<?php echo base_url();?>welcome/logout">Logout</a>
<?php //$user = $this->session->userdata('email');
//print_r($user);
$p_id = $this->session->userdata('cat_id');
?>
<a href="<?php echo site_url("welcome/add_post/".$p_id); ?>">Add Post</a> 
<a href="<?php echo site_url("welcome/home/"); ?>">Home</a> 
<h1 align="center">POST</h1> 

<?php foreach($post  as $r): ?>
<a href="<?php echo base_url(); ?>welcome/single_post/<?php echo $r->post_id; ?>"><h2 align="center"><?php echo $r->title; ?></h2></a>
<h4 align="center"><?php echo $r->description; ?></h4>
<?php 
$u_id = $user_id;
if ($u_id==$r->login_id) : ?>

	<div align="center">

	<a href="<?php echo base_url(); ?>welcome/edit_post/<?php echo $r->post_id; ?>">Edit</a>
	<a href="<?php echo base_url(); ?>welcome/delete_post/<?php echo $r->post_id; ?>">Delete</a>


	</div>	
<?php endif ?>


  <br><br>
<?php endforeach; ?>
<br><br>
<div class="pagination pagination-centered"> <ul><?php echo $this->pagination->create_links(); ?>
&nbsp;</ul> </div>
</div>
</body>
</html>